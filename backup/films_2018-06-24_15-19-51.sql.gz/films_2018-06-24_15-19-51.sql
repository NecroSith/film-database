#SXD20|20011|50638|50538|2018.06.24 15:19:51|films|0|1|7|
#TA films`7`16384
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `genre` text NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(2,'Цельнометаллическая оболочка','драма',1987),
(10,'Звездные Войны, эпизод 4 : Новая Надежда','боевик',1977),
(13,'Такси 2','комедия',2001),
(14,'Час Пик','комедия',1999),
(15,'Кошмар на улице Вязов','ужасы',2011),
(20,'Такси 3 ','комедия',2002),
(24,'Аватар','боевик',2010)	;
