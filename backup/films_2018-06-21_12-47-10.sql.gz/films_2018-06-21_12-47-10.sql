#SXD20|20011|50638|50538|2018.06.21 12:47:10|films|utf8|1|8|
#TA films`8`16384
#EOH

#	TC`films`utf8_general_ci	;
CREATE TABLE `films` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `genre` text NOT NULL,
  `year` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8	;
#	TD`films`utf8_general_ci	;
INSERT INTO `films` VALUES 
(1,'Рэмбо','боевик',1982),
(2,'Цельнометаллическая оболочка','драма',1987),
(9,'Дагон','ужасы',2001),
(10,'Звездные Войны, эпизод 4 : Новая Надежда','боевик',1977),
(13,'Такси 2','комедия',2000),
(14,'Час Пик','комедия',1999),
(15,'Кошмар на улице Вязов','ужасы',2011),
(20,'Такси 3 ','комедия',2002)	;
